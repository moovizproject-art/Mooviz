import React, { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Rocket, Smartphone, MapPinned, MessagesSquare, Truck, Users2, CheckCircle2, ArrowRight, Target, ChartLine, Wallet, Building2, Handshake, Star } from 'lucide-react'

const KPICard = ({ label, value, foot }) => (
  <div className="kpi">
    <div className="text-sm muted">{label}</div>
    <div className="text-3xl font-semibold mt-2">{value}</div>
    {foot && <div className="text-xs muted mt-1">{foot}</div>}
  </div>
)

const Step = ({ icon: Icon, title, text }) => (
  <div className="flex gap-4">
    <div className="shrink-0">
      <div className="w-12 h-12 rounded-2xl grid place-items-center shadow border">
        <Icon className="w-6 h-6" />
      </div>
    </div>
    <div>
      <div className="font-medium">{title}</div>
      <p className="text-sm muted">{text}</p>
    </div>
  </div>
)

const Section = ({ id, title, subtitle, children }) => (
  <section id={id} className="py-16 md:py-24">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="mb-10"
      >
        {title && <h2 className="text-3xl md:text-4xl font-bold tracking-tight">{title}</h2>}
        {subtitle && <p className="mt-3 muted max-w-3xl">{subtitle}</p>}
      </motion.div>
      {children}
    </div>
  </section>
)

const mockCouriers = [
  { name: 'Lior Ben-David', rating: 4.9, eta: 7, distance: 1.2 },
  { name: 'Noa Cohen', rating: 4.8, eta: 9, distance: 2.3 },
  { name: 'Avi Levi', rating: 4.7, eta: 11, distance: 2.9 },
]

function EconomicsSimulator() {
  const [distanceKm, setDistanceKm] = useState(6)
  const [parcelType, setParcelType] = useState('Small')
  const [takeRate, setTakeRate] = useState(18)
  const basePriceMap = { Small: 18, Medium: 28, Large: 44 }
  const perKmMap = { Small: 2.5, Medium: 3.2, Large: 4.1 }

  const { price, payout, margin } = useMemo(() => {
    const price = basePriceMap[parcelType] + perKmMap[parcelType] * distanceKm
    const take = price * (takeRate / 100)
    const payout = price - take
    const ops = 3.5
    const margin = take - ops
    return { price, payout, margin }
  }, [distanceKm, parcelType, takeRate])

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card p-6 space-y-6">
        <div>
          <div className="font-medium mb-1">Parcel type</div>
          <div className="flex gap-2">
            {['Small','Medium','Large'].map(t => (
              <button key={t} onClick={()=>setParcelType(t)} className={`btn ${parcelType===t?'btn-primary':'btn-outline'}`}>{t}</button>
            ))}
          </div>
        </div>

        <div>
          <div className="font-medium mb-1">Distance (km): {distanceKm}</div>
          <input type="range" min={1} max={25} value={distanceKm} onChange={e=>setDistanceKm(Number(e.target.value))} className="w-full" />
        </div>

        <div>
          <div className="font-medium mb-1">Platform take‑rate: {takeRate}%</div>
          <input type="range" min={10} max={25} value={takeRate} onChange={e=>setTakeRate(Number(e.target.value))} className="w-full" />
        </div>
      </div>

      <div className="card p-6 grid gap-4">
        <KPICard label="Customer pays (₪)" value={price.toFixed(2)} />
        <KPICard label="Courier payout (₪)" value={payout.toFixed(2)} />
        <KPICard label="Mooviz margin/delivery (₪)" value={margin.toFixed(2)} foot="after variable ops" />
        <div className="text-xs muted">Assumptions: base+km pricing, variable ops ₪3.5/order, no fixed costs. Edit in code.</div>
      </div>
    </div>
  )
}

function CourierFinder() {
  const [active, setActive] = useState(false)
  return (
    <div className="card p-6">
      <div className="grid md:grid-cols-2 gap-6 items-start">
        <div>
          <div className="font-medium mb-2">Demo: find nearby couriers</div>
          <p className="text-sm muted mb-4">This interactive mock shows how the marketplace responds in seconds.</p>
          <div className="flex gap-2">
            <button className="btn btn-primary" onClick={()=>setActive(true)}>Find couriers <ArrowRight className="w-4 h-4" /></button>
            <button className="btn btn-outline" onClick={()=>setActive(false)}>Reset</button>
          </div>
          <div className="mt-6 space-y-3">
            {active ? (
              mockCouriers.map((c,i)=>(
                <motion.div key={c.name} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{delay:0.15*i}} className="flex items-center justify-between p-3 rounded-xl border">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full grid place-items-center border">
                      <Truck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs muted">{c.distance} km away · ETA {c.eta} min</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Star className="w-4 h-4" /> {c.rating}
                    <button className="btn btn-primary text-xs px-3 py-1.5">Select</button>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-sm muted">Click “Find couriers” to simulate matching.</div>
            )}
          </div>
        </div>

        <div>
          <div className="w-full aspect-video rounded-2xl border grid place-items-center muted">
            <MapPinned className="w-8 h-8 mb-2" />
            <div className="text-sm">Map placeholder (static for demo)</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50 text-slate-900">
      <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl grid place-items-center border shadow-sm">
              <Rocket className="w-5 h-5" />
            </div>
            <div className="font-semibold text-xl">Mooviz</div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#problem">Problem</a>
            <a href="#solution">Solution</a>
            <a href="#demo">Demo</a>
            <a href="#economics">Economics</a>
            <a href="#go-to-market">Go‑to‑Market</a>
            <a href="#contact">Contact</a>
          </nav>
          <button className="btn btn-primary">Talk to us</button>
        </div>
      </header>

      <div className="relative overflow-hidden">
        <div className="container pt-16 md:pt-24 pb-10">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                Community‑powered deliveries, <span className="underline decoration-amber-400 decoration-[10px]">on‑demand</span>
              </h1>
              <p className="mt-4 text-lg muted max-w-xl">
                Mooviz connects local couriers with people and businesses for fast, affordable, and transparent deliveries.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a href="#demo" className="btn btn-primary">See live demo <ArrowRight className="w-4 h-4" /></a>
                <button className="btn btn-outline">One‑pager PDF</button>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-8">
                <KPICard label="Pilot NPS" value="+62" />
                <KPICard label="Avg. ETA" value="11 min" />
                <KPICard label="Repeat rate" value="41%" />
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }} className="grid gap-4">
              <div className="card p-6 grid gap-4">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5" />
                  <div className="font-medium">Customer app</div>
                </div>
                <div className="w-full aspect-video rounded-xl border grid place-items-center muted">Screen mock placeholder</div>
                <div className="text-xs muted">iOS & Android + Web from day 1</div>
              </div>
              <div className="card p-6 grid gap-4">
                <div className="flex items-center gap-3">
                  <Users2 className="w-5 h-5" />
                  <div className="font-medium">Courier app</div>
                </div>
                <div className="w-full aspect-[21/9] rounded-xl border grid place-items-center muted">Route & earnings mock placeholder</div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <Section id="problem" title="The problem" subtitle="Local deliveries are slow, expensive, and opaque for SMEs & neighborhoods.">
        <div className="grid md:grid-cols-3 gap-6">
          <KPICard label="SME deliveries/mo" value="25–120" foot="fragmented providers" />
          <KPICard label="Avg. delivery cost" value="₪35–70" foot="same‑day, <15km" />
          <KPICard label="Missed deliveries" value="12%" foot="no live tracking" />
        </div>
      </Section>

      <Section id="solution" title="The solution" subtitle="A community marketplace that matches nearby couriers in minutes and tracks every step.">
        <div className="grid md:grid-cols-3 gap-6">
          <Step icon={Rocket} title="Fast matching" text="Sub‑10 min average ETA in pilots with dense areas." />
          <Step icon={MessagesSquare} title="Trust & chat" text="Verified couriers, ratings, and in‑app chat for clarity." />
          <Step icon={Wallet} title="Fair economics" text="Transparent pricing and healthy courier earnings." />
        </div>
      </Section>

      <Section id="demo" title="Product demo" subtitle="Two interactive mocks to make the story tangible for investors.">
        <div className="grid gap-6">
          <CourierFinder />
          <EconomicsSimulator />
        </div>
      </Section>

      <Section id="go-to-market" title="Go‑to‑Market" subtitle="Start hyperlocal, expand through playbooks with SMEs and community hubs.">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><Target className="w-5 h-5"/><div className="font-medium">Beachhead</div></div>
            <p className="text-sm muted">Focus on 2–3 dense neighborhoods; partner with mini‑markets, florists, phone repair.</p>
          </div>
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><Handshake className="w-5 h-5"/><div className="font-medium">Supply flywheel</div></div>
            <p className="text-sm muted">Onboard community couriers (students, part‑timers) with transparent earnings.</p>
          </div>
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><Building2 className="w-5 h-5"/><div className="font-medium">SME playbooks</div></div>
            <p className="text-sm muted">Simple onboarding, dedicated chat, and recurring pickups for SMBs.</p>
          </div>
        </div>
      </Section>

      <Section id="traction" title="Early traction (pilot)" subtitle="Illustrative placeholders — replace with your real numbers before meetings.">
        <div className="grid md:grid-cols-4 gap-6">
          <KPICard label="Deliveries (mo)" value="1,250" foot="pilot cohort" />
          <KPICard label="Couriers active" value="86" />
          <KPICard label="SMEs onboarded" value="54" />
          <KPICard label="Gross margin" value="28%" />
        </div>
      </Section>

      <Section id="why-now" title="Why now" subtitle="E‑commerce continues to move local; SMBs need flexible, transparent last‑mile options.">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><ChartLine className="w-5 h-5"/><div className="font-medium">Market tailwinds</div></div>
            <p className="text-sm muted">Same‑day expectations rise; marketplaces compress delivery windows.</p>
          </div>
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><Users2 className="w-5 h-5"/><div className="font-medium">Community supply</div></div>
            <p className="text-sm muted">Flexible earners are plentiful; lightweight onboarding lowers CAC.</p>
          </div>
          <div className="card p-6 space-y-2">
            <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5"/><div className="font-medium">Mature infra</div></div>
            <p className="text-sm muted">Payments, maps, and messaging APIs make v1 fast to ship.</p>
          </div>
        </div>
      </Section>

      <Section id="contact" title="Let’s talk" subtitle="Seeking pre‑seed to execute 12‑month plan: product, pilot, and city‑level expansion.">
        <div className="grid md:grid-cols-2 gap-6 items-start">
          <div className="card p-6 space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <KPICard label="Round" value="Pre‑seed" />
              <KPICard label="Ask" value="₪750k + ₪2.0m" foot="tranches" />
              <KPICard label="Use of funds" value="Product + GTM" />
              <KPICard label="Runway" value="12–18 mo" />
            </div>
            <p className="text-sm muted">Replace with your actual raise details. Add deck link, pilot LOIs, advisors.</p>
            <div className="flex gap-3">
              <button className="btn btn-primary">Book a meeting</button>
              <button className="btn btn-outline">Email us</button>
            </div>
          </div>

          <div className="card p-6">
            <div className="w-full aspect-[16/10] rounded-2xl border grid place-items-center muted">
              <div className="text-center px-6">
                <div className="font-medium mb-1">One‑pager / Deck</div>
                <div className="text-sm">Export this page to PDF or link your deck here.</div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      <footer className="py-10 border-t">
        <div className="container text-sm muted flex items-center justify-between">
          <div>© {new Date().getFullYear()} Mooviz</div>
          <div className="flex items-center gap-4">
            <a href="#problem">Problem</a>
            <a href="#solution">Solution</a>
            <a href="#demo">Demo</a>
            <a href="#economics">Economics</a>
            <a href="#go-to-market">GTM</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
