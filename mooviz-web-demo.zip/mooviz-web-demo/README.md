# Mooviz – Investor Web Demo

Single‑page React site (Vite + Tailwind) with interactive mocks:
- Courier finder
- Unit economics simulator
- Problem / Solution / GTM / Traction sections

## Quick start
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy (Vercel)
1. Push this repo to GitHub.
2. Go to https://vercel.com → Import Project → choose the repo.
3. Framework preset: **Vite** (auto).
4. When live, add your custom domain in Vercel → Configure DNS (CNAME).

## Deploy (Netlify)
1. New site from Git → select the repo.
2. Build command: `npm run build`
3. Publish directory: `dist`

## Notes
- All metrics are placeholders — replace before investor meetings.
- Edit assumptions in `src/App.jsx` (EconomicsSimulator).
